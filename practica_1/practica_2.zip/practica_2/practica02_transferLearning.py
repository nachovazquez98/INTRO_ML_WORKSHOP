# %%
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

# %%
from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
import tensorflow as tf


# %%
tf.keras.backend.clear_session()

# %%
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        # Currently, memory growth needs to be the same across GPUs
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        logical_gpus = tf.config.experimental.list_logical_devices('GPU')
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
    except RuntimeError as e:
        # Memory growth must be set before GPUs have been initialized
        print(e)

# %%
model = ResNet50(weights='imagenet')

# %%
img = image.load_img('img.jpg', target_size=(224, 224))

# %%
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)
preds = model.predict(x)
# decode the results into a list of tuples (class, description, probability)
# (one such list for each sample in the batch)
print('Predicted:', decode_predictions(preds, top=3)[0])

# %% [markdown]
# ## Getting the dataset

# %%
import os

base_dir = '/home/nacho/Documents/Intro_AI_workshop/AI2/zaldivar/practica_2/dataset/'
train_dir = os.path.join(base_dir, 'training_set')
validation_dir = os.path.join(base_dir, 'test_set')

# %%
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing import image_dataset_from_directory

training_set = image_dataset_from_directory(train_dir,
                                             shuffle=True,
                                             batch_size=32,
                                             image_size=(150, 150))
val_dataset = image_dataset_from_directory(validation_dir,
                                                shuffle=True,
                                                batch_size=32,
                                                image_size=(150, 150))

# %%
data_augmentation = keras.Sequential(
    [       keras.layers.experimental.preprocessing.RandomFlip("horizontal"),
   keras.layers.experimental.preprocessing.RandomRotation(0.9),
    ]
)

# %%
import numpy as np
import matplotlib.pyplot as plt
for images, labels in training_set.take(1):
    plt.figure(figsize=(12, 12))
    first_image = images[0]
    for i in range(4):
        ax = plt.subplot(3, 4, i + 1)
        augmented_image = data_augmentation(
            tf.expand_dims(first_image, 0)
        )
        plt.imshow(augmented_image[0].numpy().astype("int32"))
        plt.axis("off")

# %% [markdown]
# ###########################

# %%
learning_rate_scheduler = tf.keras.optimizers.schedules.ExponentialDecay(initial_learning_rate=0.0003, 
                                                                         decay_steps=2, 
                                                                         decay_rate=0.97, 
                                                                         staircase=False)

# %%
def dense_net_model(trainable_weights=False, weights_path=None):
    
    tf.keras.backend.clear_session()
    
    dense_net = keras.applications.DenseNet201(input_shape=(150, 150, 3), weights="imagenet", include_top=False)
    
    for layer in dense_net.layers:
        layer.trainable=trainable_weights
    
    # model = tf.keras.models.Sequential([dense_net,
    #                                     tf.keras.layers.GlobalAveragePooling2D(),
    #                                     tf.keras.layers.Dense(128, activation='relu'),
    #                                     tf.keras.layers.Dropout(0.3),
    #                                     tf.keras.layers.Dense(5, activation='softmax')
    #                             ])
        
    model = tf.keras.Sequential([
            base_model,  
            tf.keras.layers.BatchNormalization(renorm=True),
            tf.keras.layers.GlobalAveragePooling2D(),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dense(256, activation='relu'),
            tf.keras.layers.Dropout(0.5),
            tf.keras.layers.Dense(128, activation='relu'),
            tf.keras.layers.Dense(5, activation='softmax')
        ])

    if weights_path:
        model.load_weights(weights_path)
    
    optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate_scheduler)
    
    model.compile(loss="categorical_crossentropy", optimizer=optimizer, metrics=['accuracy'])
    
    return model

# %%
dense_net_transfer = dense_net_model(trainable_weights=True)
dense_net_transfer_history = dense_net_transfer.fit(training_set, validation_data=val_dataset, epochs=25, steps_per_epoch=32)

# %% [markdown]
# #########################################

# %%
base_model = keras.applications.Xception(
    weights='imagenet',  
    input_shape=(150, 150, 3),
    include_top=False)  
    
base_model.trainable = False

# %%
inputs = keras.Input(shape=(150, 150, 3))

# %%
x = data_augmentation(inputs)

# %%
x = tf.keras.applications.xception.preprocess_input(x)

# %%
x = base_model(x, training=False)
x = keras.layers.GlobalAveragePooling2D()(x)
x = keras.layers.Dropout(0.2)(x)  
outputs = keras.layers.Dense(1)(x)
model = keras.Model(inputs, outputs)

# %%
# learning rate decay
learning_rate_scheduler = tf.keras.optimizers.schedules.ExponentialDecay(initial_learning_rate=0.0003, 
                                                                         decay_steps=2, 
                                                                         decay_rate=0.97, 
                                                                         staircase=False)

model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate_scheduler),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)
model.fit(training_set, epochs=20, validation_data=val_dataset)

# %%



